#ifndef __INIT_H__
#define __INIT_H__


void hw_setup();
void sys_setup();
void task_setup();

void hw_loop();
void sys_loop();
void task_loop();



#endif