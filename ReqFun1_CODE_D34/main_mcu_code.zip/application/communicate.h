#ifndef __COMMUNICATE_H__
#define __COMMUNICATE_H__

void communicate_setup();
void communicate_loop();

#endif 