#ifndef __CHASSIS_CMD_H__
#define __CHASSIS_CMD_H__

#include <time.h>
#include <stdint.h>

typedef struct chassis_cmd *chassis_cmd_t;

struct __attribute__((__packed__)) chassis_cmd
{
    int16_t vx, vy, wz; // mm/s or deg/s
};

#endif